//
//  File.swift
//  
//
//  Created by Junior on 24/07/22.
//

import Foundation
public protocol BDRModule {
    
}
