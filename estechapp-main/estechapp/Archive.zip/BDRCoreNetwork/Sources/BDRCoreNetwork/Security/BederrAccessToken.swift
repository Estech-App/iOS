//
//  BederrAccessToken.swift
//  
//
//  Created by Junior on 5/12/21.
//

import Foundation

public struct BederrAccessToken: Decodable {
    public let token: String
}
